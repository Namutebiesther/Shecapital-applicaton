import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../Services/global_variables.dart';

class   Persistent{
  static List<String> jobCategoryList =[
    'Programming and Technology',
    'Education and Training',
    'Business',
    'service and delivery(no qaulification)',
    'Marketing',
    'Accounting',
    'construction',
    'Health service',
    'Others',
  ];
  void getMyData() async{
    final DocumentSnapshot userDoc = await FirebaseFirestore.instance.collection('users').doc(FirebaseAuth.instance.currentUser!.uid).get();

      name = userDoc.get('name');
      userImage = userDoc.get('UserImage');
      location =userDoc.get('location');

  }
}