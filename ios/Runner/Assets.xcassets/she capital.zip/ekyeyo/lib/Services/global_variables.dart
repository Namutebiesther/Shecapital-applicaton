
String loginUrlImage = 'https://wallpaperaccess.com/full/656702.jpg';
String signupUrlImage ='https://img.freepik.com/free-photo/portrait-handsome-african-black-young-business-man-working-laptop-office-desk_231208-680.jpg?w=740&t=st=1686831640~exp=1686832240~hmac=b30077abd79834f550bef944420e5746641ed0daeceaa09f7933897d0461c645';
String  forgotUrlImage ='https://e0.pxfuel.com/wallpapers/850/829/desktop-wallpaper-e-commerce-web-designing-development-company-e-commerce.jpg';
String? name = '';
String? userImage ='';
String?  location ='';