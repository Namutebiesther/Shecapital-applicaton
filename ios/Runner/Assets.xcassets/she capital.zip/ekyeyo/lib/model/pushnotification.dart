class PushNotification{
  PushNotification({
    this.title,
    this.body,
    this.databody,
    this.dataTitle,
});


  String? title;
  String? body;
  String? dataTitle;
  String? databody;
}