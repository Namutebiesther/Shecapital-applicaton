package com.example.ekyeyo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
